# Answer to the commentary of Prof. James Higgins

We thank Prof. Higgins for his commentary on our article. We clarify that the interaction interpretation issues (extensively discussed in our paper) are not the cause of ART’s clear failure in the example shown in Figure 1, where ART falsely detects (with very high confidence) both a main effect and an interaction effect that do not exist.

We also explain why the simulation model used by Prof. Higgins and his students in their early studies of ART is overly simplistic, failing to simulate distributions observed in real data and thereby masking ART's fundamental flaws. As we explain, *"despite decades of its study and analysis by statisticians"* (see comment by Prof. Wobbrock), ART's critical issues, as demonstrated by our experiments, have been largely overlooked. We encourage Prof. Higgins and Prof. Wobbrock to conduct their own experiments to verify our findings using on their more recent simulation methodology, as described by Elikin et al. (2021). We suggest they extend their experiments to include strong non-null effects on secondary factors, as well as to account for ordinal data and discrete distributions.   

While we further discuss the interaction interpretation issues raised by Prof. Higgins, we emphasize that these are irrelevant to the specific example in Figure 1. We conclude with our suggestions for revising our article to incorporate insights from this discussion.

## Figure 1: Illustrative example
We mention in the article: *"Time performances have been randomly sampled from a population in which: (1) Difficulty has a large effect; (2) Technique has no effect; and (3) there is no interaction effect between the two factors."* 

The fact that there is no effect of Technique and no interaction effect in the population is important to understand why the argumentation of Prof. Higgins is misleading. We discuss both main and interaction effects.

### Effect of Technique
Prof. Higgins does not comment on the fact that ART detects a main effect of *Technique* with an extremely low *p*-value. The discrepancy with the results of the other methods is huge and cannot be attributed to non-linear data transformations and interpretation issues. As we explain in the paper, monotonic transformations do not alter the interpretation of the null hypothesis in main effects. Unfortunately, as we demonstrate in Figure 2, ART is not a monotonic transformation, since it does not preserve the original order of data values.

Isn't reasonable to say here that ART clearly fails? Notice that this is not an isolated case. If we repeatedly generate data from such populations for this experimental design, we will observe the Type I errors shown in Figure 10 (Log-normal). Sadly, ART's failure is systematic. 

### Interaction effect
Prof. Higgins argues that the discrepancy between the *p*-values obtained with ART and three other transformation methods (LOG, RNK, and INT) are due to the non-linear transformations that those methods apply. He disregards however the fact that the data for Figure 1 were sampled from a population where there is a main effect on a single factor (*Difficulty*) and no interaction. It is easy to show that in this case, a monotonic (even non-linear) transformation will not affect the definition of the null hypothesis for the interaction, that is, there will be an interaction effect in the transformed data if only if there is an interaction effect in the observed non-transformed data. In other words, the "*definition of interaction*" is not a issue here.

Interaction interpretation issues would only emerge if a strong effect appeared on both factors. Contrary to what Prof. Higgins states (*"... they misunderstood what interaction is fundamentally about"*), our paper provides an extensive analysis of interaction interpretation issues. But those issues are irrelevant to the example of Figure 1, and thus cannot explain the discrepancy between the results of ART and the results of the other transformation methods. We had carefully chosen our illustrative example to avoid such misunderstandings.

Prof. Higgins believes that *"there IS interaction in the
data"* but this not the case simply because there was no interaction effect in the original population. The observed patterns are random fluctuations. If we repeat the data generation process multiple times, we will observe that there is no winning technique, regardless of which difficulty level we focus on. The lower time observed for Technique C (in red) under Level4 is a random result that can be easily explained by the high variability of the data points. The following figure presents means from six different samples from the same population, where we clearly see that the interaction trends are completely random: 

![Interactions](example-interactions.png)

If we now generate a large number of samples and use the various methods to test the interaction, we will observe the Type I error rate trends shown in our Figure 12 (Log-normal). ART is the only method that inflates error rates. There is no ambiguity on how we define interactions in this case. Once again, ART simply fails. 

## Why Higgins' simulation model is naive 
We now understand why older simulation studies did not reveal how ART struggles with heavy tailed distributions. As Higgins explains, his stimulation studies were based on the model: 

$Y =  \mu + a_i + b_j +ab_{ij} + error$ 

where non-normal distributions were simply applied to the error term. Mansouri and Chang (1995) seem to have followed the same strategy, as implied from Page 87. Unfortunately, this approach results in naive distributions for the response variable $Y$, which have little to do with real data generation processes in behavioral sciences and HCI. 

Suppose we studied a selection task, measuring the time participants needed to acquire a target using four different input techniques. Higgins' simulation model would generate distribution shapes for $Y$ (time in seconds here) similar to those shown below:   

![model1](higgins-model.png)

We observe that the distribution of slower techniques is simply shifted to the right, while their shape conveniently remains identical. We agree that ART will behave correctly in this scenario. However, such distributions are not realistic. 

Heavy-tailed distributions, such as the log-normal distribution here, commonly arise in nature (Limpert et al., 2001) when measurements cannot be negative or fall below a certain threshold, e.g., the minimum time needed to react to a visual stimulus. In most experimental research, however, this threshold does not shift across conditions while preserving the distribution’s shape. Instead, distributions are more likely to resemble the following:

![model2](alt-model.png)

In these distributions, the mean for slower techniques also increases, but this increase is not reflected as a simple global shift in the distribution. Instead, the overall shape of the distribution changes. The model for these distributions is structured as follows:

 $log(Y - \theta) = \mu + a_i + b_j + ab_{ij} + error$ 
 
 where the error term is normally distributed, and $\theta$ represents a threshold below which response values cannot occur. For simplicity, we only study log-normal distributions with $\theta = 0$ in our article, but in certain experimental scenarios (Wagenmakers et al., 2007), a non-zero threshold is more appropriate.  

An interesting characteristic of these distributions is that as their mean increases, their standard deviation also increases linearly. In our article, we cite Wagenmakers et al. (2007), who provide empirical evidence for this pattern based on an analysis of nine independent response-time experiments. This trend is common in studies assessing task-completion time, whether the task is visual, motor, or cognitive. As tasks become more difficult and prolonged, variance tends to increase. Similarly, slower participants generally exhibit greater variance across tasks compared to faster, more practiced users. We emphasize, however, that the variance of the error term still remains fixed in this example. The fact that the variance of $Y$ changes with the mean is an inherent property of the non-linear nature of the logarithmic function (and by extension, its inverse). And as our article demonstrates, ART's alignment method fails in such cases, as it tends to confound effects.

Our readers may note that Elkin et al. (2021) diverged from the modeling approach described by Prof. Higgins. Their methodology (illustrated by their example in Section 3 and their data generation procedures in Section 5.1) aligns closely with our own approach outlined above. So why did Elkin et al. (2021) fail to identify the issues we raise in our article? There are two main reasons:

1. Their experiments assessed Type I error rates only in scenarios where main effects on all factors were null. Consequently, they couldn’t observe how ART confounds effects under heavy-tailed distributions.

2. They tested only continuous distributions, missing ART’s failure in handling discrete distributions, such as binomial distributions and Likert-type data. Prof. Wobbrock and Prof. Higgins do not comment on our results on discrete distributions, nor the limited past evaluations of ART on such data. We found no prior assessments of ART on binomial distributions, and Lüpsen’s (2017) warnings about ART’s failure with discrete scales of few levels have been largely overlooked by HCI researchers, who frequently use ART specifically for this type of data.

Furthermore, Elkin et al. (2021) compared ART only to the t-test. Had they included INT in their evaluations, they would have found that this much simpler method has greater power than ART in the scenarios they tested.

## Interaction interpretation issues

## References 
1. Elkin, Lisa A., Matthew Kay, James J. Higgins, and Jacob O. Wobbrock. 2021. “An Aligned Rank Transform Procedure for Multifactor Contrast Tests.” In The 34th Annual ACM Symposium on User Interface Software and Technology, 754–68. UIST ’21. New York, NY, USA: Association for Computing Machinery. https://doi.org/10.1145/3472749.3474784.

2. Higgins, James J., R. Clifford Blair, and Suleiman Tashtoush. 1990. “The Aligned Rank Transform Procedure.” In Conference on Applied Statistics in Agriculture. https://doi.org/10.4148/2475-7772.1443.

3. Mansouri, H., and G.-H. Chang. 1995. “A Comparative Study of Some Rank Tests for Interaction.” Computational Statistics & Data Analysis 19 (1): 85–96. https://doi.org/10.1016/0167-9473(93)E0045-6.

4. Limpert, Eckhard, Werner A. Stahel, and Markus Abbt. 2001. “Log-normal Distributions across the Sciences: Keys and Clues.” BioScience 51 (5): 341–52. https://doi.org/10.1641/0006-3568(2001)051[0341:LNDATS]2.0.CO;2.

5. Lüpsen, Haiko. 2017. “The Aligned Rank Transform and Discrete Variables: A Warning.” Communications in Statistics - Simulation and Computation 46 (9): 6923–36. https://doi.org/10.1080/03610918.2016.1217014.

6. Wagenmakers, Eric-Jan, and Scott Brown. 2007. “On the Linear Relation Between the Mean and the Standard Deviation of a Response Time Distribution.” Psychol Rev 114 (3): 830–41. https://doi.org/10.1037/0033-295X.114.3.830.
